var questions = [
    {
      title: "Commonly used data types DO NOT include:",
      choices: ["strings", "booleans", "alerts", "numbers"],
      answer: "alerts"
    },
    {
      title: "The condition in an if / else statement is enclosed within ____.",
      choices: ["quotes", "curly brackets", "parentheses", "square brackets"],
      answer: "parentheses"
    },
   {

    title: "What does HTML stands for?",
    choices: ['hyper Text Markup Language',
     'hyperlinks and Text Markup Language',
     'Home Tool Markup Language',
    'Hyena Thinks of Making Lunch'],
    answer: 'hyper Text Markup Language'
   },
  
    ///etc.
  ];
  